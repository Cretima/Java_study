
public class Hello2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("안녕하세요");
		System.out.print("홍길동입니다."); // ln은 줄바꿈
		System.out.println("Hello World!");
	}

}
